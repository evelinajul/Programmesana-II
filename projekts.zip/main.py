from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_login import current_user, login_user, logout_user
import sqlite3, os, pwd, hashlib

app = Flask(__name__)
app.secret_key = 'cup2gram230806207110511'

konekcija = sqlite3.connect('receptes_dati.db')
db = konekcija.cursor()

command6 = """CREATE TABLE IF NOT EXISTS lietotaji( \
             lietotajs_id INTEGER PRIMARY KEY AUTOINCREMENT, \
             lietotajvards TEXT UNIQUE,\
             parole TEXT NOT NULL)"""
db.execute(command6)

command1 = """CREATE TABLE IF NOT EXISTS mertabula( \
             id INTEGER PRIMARY KEY AUTOINCREMENT, \
             nosaukums TEXT NOT NULL, \
             cup REAL NOT NULL, \
             spoon REAL NOT NULL)"""
db.execute(command1)

command3 = """CREATE TABLE IF NOT EXISTS recepte( \
             recepte_id INTEGER PRIMARY KEY AUTOINCREMENT, \
             nosaukums TEXT NOT NULL, \
             lietotajs_id INTEGER, \
             FOREIGN KEY(lietotajs_id) REFERENCES lietotaji(lietotajs_id))"""
db.execute(command3)

command2 = """CREATE TABLE IF NOT EXISTS izejvielas(
    produkts_id INTEGER PRIMARY KEY AUTOINCREMENT,
    nosaukums TEXT NOT NULL,
    daudzums INTEGER NOT NULL,
    mervieniba DEFAULT 'g',
    recepte_id INTEGER,
    FOREIGN KEY(recepte_id) REFERENCES receptes(recepte_id))"""
db.execute(command2)

command5 = """CREATE TABLE IF NOT EXISTS instrukcija( \
             instrukcija_id INTEGER PRIMARY KEY AUTOINCREMENT, \
             recepte_id INTEGER, \
             teksts TEXT NOT NULL, \
             FOREIGN KEY(recepte_id) REFERENCES receptes(recepte_id))"""
db.execute(command5)
konekcija.commit()

@app.route('/')
def sakums():
    return render_template('sakums.html')

@app.route('/jauns_profils')
def jauns_profils():
    return render_template('jauns_profils.html')

@app.route('/register', methods=['POST'])
def register():
    msg = ""
    if request.method == 'POST' and 'lietotajvards' in request.form and 'parole' in request.form:
        lietotajvards = request.form['lietotajvards']
        parole = request.form['parole']
        account = select_sql_one("SELECT * FROM lietotaji WHERE lietotajvards = ?", (lietotajvards,))
        if account:
            msg = 'Šis lietotājs jau eksistē!' 
        elif not lietotajvards or not parole:
            msg = 'Lūdzu aizpildiet visus laukus!'
        else:
            insert_sql("INSERT INTO lietotaji (lietotajvards, parole) VALUES (?, ?)", (lietotajvards, parole))
    return render_template('sakums.html') 
    

@app.route('/login', methods =['GET', 'POST'])
def login():
    if request.method == 'POST' and 'lietotajvards' in request.form and 'parole' in request.form:
        lietotajvards = request.form['lietotajvards']
        parole = request.form['parole']
        account = select_sql_one("SELECT * FROM lietotaji WHERE lietotajvards = ? AND parole = ?", (lietotajvards, parole,))
        if account:
            session['loggedin'] = True
            session['id'] = account['lietotajs_id']
            session['username'] = account['lietotajvards']
            return render_template('home.html')
        else:
            flash('Nepareizs lietotājvārds/parole!')
            return render_template('sakums.html')
    return render_template('home.html')

@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/logout')
def logout():
    session.pop('loggedin', None)
    session.pop('id', None)
    session.pop('username', None)
    return redirect('/')

@app.route('/saglabat_datus_produkts', methods=['GET', 'POST'])
def saglabat_datus_produkts():
  if request.method == "POST":
    nosaukums = request.form["nosaukums"]
    cups = request.form["daudzglaze"]
    spoons = request.form["daudzkarote"]
    cups = float(cups)
    spoons = float(spoons)
    insert_sql("INSERT INTO mertabula(nosaukums, cup, spoon) VALUES(?,?,?)", (
        nosaukums,
        cups,
        spoons,
    ))
  return render_template("home.html")


@app.route('/jauna_recepte')
def recepte():
  veidi = select_sql("SELECT * FROM Veidi", ())
  izejvielas = select_sql("SELECT * FROM mertabula")
  return render_template('jaunarecepte.html',
                         veidi=veidi,
                         izejvielas=izejvielas)

@app.route('/saglabat_datus_recepte', methods=['GET', 'POST'])
def saglabat_datus_recepte():
    if request.method == "POST":
        nosaukums = request.form["nosaukums"]
        user_id = 1  
        insert_sql("INSERT INTO recepte(nosaukums, lietotajs_id) VALUES(?, ?)",
                       (nosaukums, user_id))
            # Get the last inserted recepte_id
        recepte_id = get_sequence_value('recepte')
        izejvielas = request.form.getlist("izejviela")
        daudzumi = request.form.getlist("daudzums")
        mervienibas = request.form.getlist("mervieniba")
        for i in range(len(izejvielas)):
            izejviela_id = int(izejvielas[i])
            nosaukums_izejviela = select_sql(
            "SELECT nosaukums FROM mertabula WHERE id=?", (izejviela_id, ))[0][0]
            if mervienibas[i] == '1':
                x = select_sql("SELECT cup FROM mertabula WHERE nosaukums=?", (nosaukums_izejviela, ))[0][0]
            else:
                x = select_sql("SELECT spoon FROM mertabula WHERE nosaukums=?",(nosaukums_izejviela, ))[0][0]
            daudzums = x * float(daudzumi[i]) 
            insert_sql("INSERT INTO izejvielas(nosaukums, daudzums, recepte_id) VALUES(?, ?, ?)",
                           (nosaukums_izejviela, daudzums, recepte_id))
    return render_template('pazinojums.html')


@app.route('/parveidot')
def parveidot():
    recepte_id = get_sequence_value('recepte')
    izejvielas = select_sql("SELECT * FROM izejvielas WHERE recepte_id = ?", (recepte_id,))
    recepte = select_sql("SELECT * FROM recepte WHERE recepte_id = ?", (recepte_id,))
    return render_template('parveidojums.html', izejvielas=izejvielas, recepte=recepte)


@app.route('/jauna_recepte2')
def recepte2():
  return render_template('jaunarecepte2.html',)


@app.route('/saglabat_datus_recepte2', methods=['GET', 'POST'])
def saglabat_datus_recepte2():
  recepte_id = get_sequence_value('recepte')
  if request.method == "POST":
    izejvielas = request.form.getlist("izejviela")
    daudzumi = request.form.getlist("daudzums")
    mervienibas = request.form.getlist("mervieniba")
    for i in range(len(daudzumi)):
      izejviela = izejvielas[i]
      daudzums = daudzumi[i]
      mervieniba = mervienibas[i]
      insert_sql(
        "INSERT INTO izejvielas(nosaukums, daudzums, mervieniba, recepte_id) VALUES(?,?,?,?)",
        (izejviela, daudzums, mervieniba, recepte_id))
  return render_template('jaunarecepte3.html')


@app.route('/saglabat_datus_recepte3', methods=['GET', 'POST'])
def saglabat_datus_recepte3():
    if request.method == "POST":
        teksts = request.form["instrukcija"]
        recepte_id = get_sequence_value('recepte')
        insert_sql("INSERT INTO instrukcija(recepte_id, teksts) VALUES(?, ?)", (recepte_id, teksts, ))
    return render_template("home.html")

@app.route('/saraksts')
def saraksts():
    receptes = select_sql("""
    SELECT r.recepte_id, r.nosaukums, r.lietotajs_id, 
                   i.teksts AS instrukcija_teksts
            FROM recepte r
            JOIN instrukcija i ON r.recepte_id = i.recepte_id
        """)
    instrukcijas= select_sql("SELECT * FROM instrukcija")
    izejvielas = select_sql("SELECT * FROM izejvielas")
    return render_template('saraksts.html', receptes=receptes, izejvielas=izejvielas, instrukcijas=instrukcijas)

@app.route('/jauns_produkts')
def jauns_produkts():
  return render_template('produkts.html')

def select_sql(cmd, vals=()):
   konekcija = sqlite3.connect('receptes_dati.db')
   konekcija.row_factory = sqlite3.Row 
   db = konekcija.cursor()
   res = db.execute(cmd, vals).fetchall()
   konekcija.commit()
   return res

def select_sql_one(cmd, vals=()):
    konekcija = sqlite3.connect('receptes_dati.db')
    konekcija.row_factory = sqlite3.Row 
    db = konekcija.cursor()
    res = db.execute(cmd, vals).fetchone()
    konekcija.commit()
    return res

def insert_sql(cmd, vals=()):
   konekcija = sqlite3.connect('receptes_dati.db') 
   db= konekcija.cursor()
   db.execute(cmd, vals)  
   konekcija.commit()     
   konekcija.close() 

def clear_table(table_name):
  conn = sqlite3.connect('receptes_dati.db')
  cursor = conn.cursor()
  cursor.execute(f"DELETE FROM {table_name}")
  conn.commit()
  conn.close()

def get_sequence_value(table_name):
    query = "SELECT seq FROM sqlite_sequence WHERE name = ?"
    result = select_sql(query, (table_name,))
    if result:
        return result[0][0]
    else:
        return None 

def execute_sql(query, params=()):
    conn = sqlite3.connect('receptes_dati.db')
    cursor = conn.cursor()
    cursor.execute(query, params)
    conn.commit()
    conn.close()

if __name__ == "__main__":
  app.run(host='0.0.0.0', port=8080)
